chrome.runtime.onInstalled.addListener(async () => {
  chrome.contextMenus.create({
    id: "ru",
    title: "Открыть в BPM",
    type: 'normal',
    contexts: ['selection']
  });
});

chrome.contextMenus.onClicked.addListener((item, tab) => {
var query = item.selectionText;
if (/^SR\d{8}$/.test(query)){
  chrome.tabs.create({url: "http://c3po.corp.tele2.ru/bpm/number/" + query, index: tab.index + 1 });
}
});


function openDebug() {
    a = window.location.hash
    if (a.startsWith("#CardModuleV2/CasePage/edit/")){
      let srnum
      const header = document.getElementById("MainHeaderSchemaPageHeaderCaptionLabel")
      const service = document.getElementById("CasePageServiceItemLookupEdit-link-el")
      const TIBEZPRAVILOH = document.getElementById("t-comp0-caption")

      const scriptField = document.getElementById("CasePageUsrScriptLookupEdit-el")
      const scriptRestartButton = document.getElementById("CasePageUsrRestartScriptButtonButton-textEl")

      if (scriptField?.value && scriptRestartButton.classList.contains('t-btn-disabled')){
        const n = a.lastIndexOf('/');
        const caseid = a.substring(n + 1);
        const url = "http://c3po.corp.tele2.ru/bpmfix/"+caseid
        window.open(url)
        return
      }

      if (TIBEZPRAVILOH?.textContent == "Обращение не существует или у Вас нет прав на его просмотр!"){
        const n = a.lastIndexOf('/');
        const caseid = a.substring(n + 1);
        const url = "http://c3po.corp.tele2.ru/addinteres/"+caseid
        window.open(url)
        return
      }

      if (header) {
        if (service.textContent === "Ошибка выполнения скрипта"){
          const sr_text = document.getElementById("CasePageSymptomsMemoEdit-el")
          srnum = sr_text.value.match(/SR\d+/i)[0]
        }else{
          srnum = header.textContent.match(/SR\d+/i)[0]
        }
        const url = "http://c3po.corp.tele2.ru/srnumber/"+srnum
        window.open(url)
      }
    }
  }

  chrome.action.onClicked.addListener((tab) => {
    if(!tab.url.includes("chrome://")) {
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        function: openDebug
      });
    }
  });
